export const subscribeToPush = async (token: string) => {
  if (!('serviceWorker' in navigator) || !('PushManager' in window)) return;
  
  if (Notification.permission !== 'granted') return;

  try {
    const registration = await navigator.serviceWorker.ready;
    console.log('ServiceWorker ready. Attempting to subscribe...');
    
    let subscription = await registration.pushManager.getSubscription();
    
    if (!subscription) {
      const res = await fetch('/api/notifications/vapid-public-key');
      const { publicKey } = await res.json();
      
      if (publicKey) {
        const padding = '='.repeat((4 - publicKey.length % 4) % 4);
        const base64 = (publicKey + padding).replace(/\-/g, '+').replace(/_/g, '/');
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        for (let i = 0; i < rawData.length; ++i) {
          outputArray[i] = rawData.charCodeAt(i);
        }
        
        subscription = await registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: outputArray
        });
      }
    }

    if (subscription) {
      await fetch('/api/notifications/subscribe', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ subscription })
      });
      console.log('Push notification successfully subscribed with server.');
    }
  } catch (err) {
    console.error('Service Worker / Push API setup failed:', err);
  }
};
