import express from "express";
import Notification from "../models/Notification.js";
import User from "../models/User.js";
import { verifyToken } from "../middleware/auth.js";
import { getPublicKey } from "../utils/webpush.js";

const router = express.Router();

// Get VAPID public key
router.get("/vapid-public-key", (req, res) => {
  const key = getPublicKey();
  res.json({ publicKey: key });
});

// Subscribe to push notifications
router.post("/subscribe", verifyToken, async (req: any, res) => {
  try {
    const { subscription } = req.body;
    const user = await User.findById(req.user.id);
    if (!user) return res.status(404).json({ message: "User not found" });

    // initialize if undefined
    if (!user.pushSubscriptions) {
      user.pushSubscriptions = [];
    }

    // prevent duplicate subscriptions (based on endpoint)
    const exists = user.pushSubscriptions.some(sub => sub.endpoint === subscription.endpoint);
    if (!exists) {
      user.pushSubscriptions.push(subscription);
      await user.save();
    }

    res.status(201).json({ message: "Subscribed successfully" });
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

// Get user notifications
router.get("/", verifyToken, async (req: any, res) => {
  try {
    const notifications = await Notification.find({ user: req.user.id })
      .sort({ createdAt: -1 })
      .limit(20);
    res.json(notifications);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

// Mark as read
router.put("/:id/read", verifyToken, async (req: any, res) => {
  try {
    const notification = await Notification.findOneAndUpdate(
      { _id: req.params.id, user: req.user.id },
      { read: true },
      { new: true }
    );
    res.json(notification);
  } catch (error) {
    res.status(500).json({ message: "Server error", error });
  }
});

export default router;
