/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { Routes, Route, Navigate, useNavigate, useLocation } from 'react-router-dom';
import { Toaster } from 'react-hot-toast';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import FindDonors from './pages/FindDonors';
import RequestBlood from './pages/RequestBlood';
import About from './pages/About';
import Team from './pages/Team';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Register from './pages/Register';
import Profile from './pages/Profile';
import Admin from './pages/Admin';
import Footer from './components/Footer';

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const loggedIn = localStorage.getItem('isLoggedIn') === 'true';
    setIsLoggedIn(loggedIn);

    const setupPush = async () => {
      // Basic generic notification request
      if ('Notification' in window && Notification.permission === 'default') {
        await Notification.requestPermission();
      }

      // If supported, register SW and subscribe to Push API
      if ('serviceWorker' in navigator && 'PushManager' in window && loggedIn) {
        try {
          const registration = await navigator.serviceWorker.register('/sw.js');
          console.log('ServiceWorker registered successfully.');
          
          if (Notification.permission === 'granted') {
            const token = localStorage.getItem('token');
            if (!token) return;
            
            // Check if we already have a subscription for this device
            const existingSub = await registration.pushManager.getSubscription();
            if (!existingSub) {
              const res = await fetch('/api/notifications/vapid-public-key');
              const { publicKey } = await res.json();
              
              if (publicKey) {
                // convert base64 to Uint8Array
                const padding = '='.repeat((4 - publicKey.length % 4) % 4);
                const base64 = (publicKey + padding).replace(/\-/g, '+').replace(/_/g, '/');
                const rawData = window.atob(base64);
                const outputArray = new Uint8Array(rawData.length);
                for (let i = 0; i < rawData.length; ++i) {
                  outputArray[i] = rawData.charCodeAt(i);
                }
                
                const subscription = await registration.pushManager.subscribe({
                  userVisibleOnly: true,
                  applicationServerKey: outputArray
                });
                
                // Send subscription to backend
                await fetch('/api/notifications/subscribe', {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${token}`
                  },
                  body: JSON.stringify({ subscription })
                });
                console.log('Push notification subscribed.');
              }
            }
          }
        } catch (err) {
          console.error('Service Worker / Push API setup failed:', err);
        }
      }
    };
    
    setupPush();
  }, [isLoggedIn]);

  const handleLogin = () => {
    setIsLoggedIn(true);
    localStorage.setItem('isLoggedIn', 'true');
    navigate('/profile');
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('token');
    localStorage.removeItem('user');
    navigate('/home');
  };

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-50 dark:bg-[#0a0a0a] text-gray-900 dark:text-gray-900 dark:text-white font-sans selection:bg-red-500/30 pb-16 md:pb-0">
      <Toaster />
      <Navbar isLoggedIn={isLoggedIn} onLogout={handleLogout} />
      <Routes>
        <Route path="/" element={<Navigate to="/home" replace />} />
        <Route path="/home" element={<Home />} />
        <Route path="/find-donors" element={<FindDonors />} />
        <Route path="/request-blood" element={<RequestBlood />} />
        <Route path="/about" element={<About />} />
        <Route path="/team" element={<Team />} />
        <Route path="/contact" element={<Contact />} />
        <Route path="/login" element={<Login onLogin={handleLogin} />} />
        <Route path="/register" element={<Register onLogin={handleLogin} />} />
        <Route path="/profile" element={isLoggedIn ? <Profile onLogout={handleLogout} /> : <Navigate to="/login" replace />} />
        <Route path="/admin" element={<Admin />} />
        <Route path="*" element={<Navigate to="/home" replace />} />
      </Routes>
      <Footer />
    </div>
  );
}
