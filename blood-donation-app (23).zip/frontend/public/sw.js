self.addEventListener('push', function(e) {
  if (e.data) {
    const data = e.data.json();
    console.log('Push message received:', data);
    
    const options = {
      body: data.message,
      icon: '/vite.svg',
      badge: '/vite.svg',
      data: {
        url: data.link || '/'
      }
    };
    
    e.waitUntil(
      self.registration.showNotification(data.title || 'Blood Link Notification', options)
    );
  }
});

self.addEventListener('notificationclick', function(e) {
  e.notification.close();
  const urlToOpen = e.notification.data.url;
  
  e.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(windowClients) {
      // Check if there is already a window/tab open with the target URL
      for (let i = 0; i < windowClients.length; i++) {
        const client = windowClients[i];
        // If so, just focus it.
        if (client.url.includes(urlToOpen) && 'focus' in client) {
          return client.focus();
        }
      }
      // If not, then open the target URL in a new window/tab.
      if (clients.openWindow) {
        return clients.openWindow(urlToOpen);
      }
    })
  );
});
