import http from 'http';

http.get('http://localhost:3000/src/main.tsx', (res) => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => console.log('STATUS:', res.statusCode, 'DATA_START:', data.slice(0, 200)));
}).on('error', err => console.error(err));
