import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', '');

  return {
    root: 'frontend',

    plugins: [
      react(),
      tailwindcss(),

      // ADD THIS
      VitePWA({
        registerType: 'prompt',
        devOptions: {
          enabled: true,
          type: 'classic'
        },
        manifest: {
          name: 'BloodLink',
          short_name: 'BloodLink',
          description: 'Blood Donation Platform',
          theme_color: '#000000',
          background_color: '#000000',
          display: 'standalone',
          start_url: '/',
          icons: [
            {
              src: '/pwa-192x192.png',
              sizes: '192x192',
              type: 'image/png',
            },
            {
              src: '/pwa-512x512.png',
              sizes: '512x512',
              type: 'image/png',
            },
          ],
        },
        workbox: {
          importScripts: ['firebase-messaging-sw.js']
        }
      }),
    ],

    define: {
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY),
    },

    resolve: {
      alias: {
        '@': path.resolve(__dirname, './frontend/src'),
      },
    },

    server: {
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // We explicitly set it to false so it stops throwing '[vite]' websocket errors in console.
      hmr: false,
    },

    build: {
      outDir: '../dist',
      emptyOutDir: true,
    },
  };
});
