import http from 'http';
http.get('http://0.0.0.0:3000/firebase-messaging-sw.js', (res) => {
  let data = '';
  res.on('data', chunk => data += chunk);
  res.on('end', () => console.log('Status:', res.statusCode, '\nData:', data.substring(0, 500)));
}).on('error', err => console.error(err));
