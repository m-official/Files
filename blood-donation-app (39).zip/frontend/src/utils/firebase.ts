import { initializeApp } from "firebase/app";
import { getMessaging, getToken, onMessage } from "firebase/messaging";

const firebaseConfig = {
  apiKey: "AIzaSyBVZ_ZrTIpoe-NcTPlPbSCVFYRq0X1tZ-I",
  authDomain: "bloodlink-61bb7.firebaseapp.com",
  projectId: "bloodlink-61bb7",
  storageBucket: "bloodlink-61bb7.firebasestorage.app",
  messagingSenderId: "426841026024",
  appId: "1:426841026024:web:f38fdd9fa3f845b191885d",
  measurementId: "G-NREL7XZ6T4"
};

const app = initializeApp(firebaseConfig);
export const messaging = getMessaging(app);

export const VAPID_KEY = "BGvB7-9D1cfiXYYGKxHgadEUlku759PLz4VqO77VJoMX-e35VN-peRiaY_sKT8qZBcDAciELXS5B1JIOAgYF-nI";

export const requestFirebaseNotificationPermission = async () => {
    try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
            const registration = await navigator.serviceWorker.ready;
            
            const currentToken = await getToken(messaging, { 
                vapidKey: VAPID_KEY,
                serviceWorkerRegistration: registration 
            });
            if (currentToken) {
                return currentToken;
            } else {
                console.log('No registration token available. Request permission to generate one.');
                return null;
            }
        }
    } catch (err) {
        console.log('An error occurred while retrieving token. ', err);
        return null;
    }
};

export const setupOnMessageListener = (callback: (payload: any) => void) => {
    return onMessage(messaging, (payload) => {
        callback(payload);
    });
};
