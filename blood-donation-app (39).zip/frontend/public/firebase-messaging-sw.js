importScripts('https://www.gstatic.com/firebasejs/9.2.0/firebase-app-compat.js');
importScripts('https://www.gstatic.com/firebasejs/9.2.0/firebase-messaging-compat.js');

const firebaseConfig = {
    apiKey: "AIzaSyBVZ_ZrTIpoe-NcTPlPbSCVFYRq0X1tZ-I",
    authDomain: "bloodlink-61bb7.firebaseapp.com",
    projectId: "bloodlink-61bb7",
    storageBucket: "bloodlink-61bb7.firebasestorage.app",
    messagingSenderId: "426841026024",
    appId: "1:426841026024:web:f38fdd9fa3f845b191885d",
    measurementId: "G-NREL7XZ6T4"
};

firebase.initializeApp(firebaseConfig);
const messaging = firebase.messaging();

messaging.onBackgroundMessage((payload) => {
    console.log('[firebase-messaging-sw.js] Received background message ', payload);
    const notificationTitle = payload.data?.title || payload.notification?.title || 'BloodLink';
    const notificationOptions = {
        body: payload.data?.message || payload.notification?.body || 'You have a new notification',
        icon: '/icon.svg',
        data: {
          url: payload.data?.link || '/'
        }
    };
    
    // Return promise so the browser knows we are handling it
    return self.registration.showNotification(notificationTitle, notificationOptions);
});

self.addEventListener('notificationclick', function(event) {
    event.notification.close();
    if (!event.notification.data || !event.notification.data.url) return;
    
    event.waitUntil(
        clients.matchAll({ type: 'window' }).then((windowClients) => {
            // Check if there is already a window/tab open with the target URL
            for (let i = 0; i < windowClients.length; i++) {
                const client = windowClients[i];
                if (client.url.includes(event.notification.data.url) && 'focus' in client) {
                    return client.focus();
                }
            }
            // If not, open a new window
            if (clients.openWindow) {
                return clients.openWindow(event.notification.data.url);
            }
        })
    );
});
