import express from "express";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import { connectDB } from "./config/db.js";
import { createServer } from "http";
import { Server } from "socket.io";
import jwt from "jsonwebtoken";
import { initWebPush } from "./utils/webpush.js";

// Import routes
import authRoutes from "./routes/auth.js";
import requestRoutes from "./routes/requests.js";
import userRoutes from "./routes/users.js";
import directRequestRoutes from "./routes/directRequests.js";
import notificationRoutes from "./routes/notifications.js";

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

async function startServer() {
  const app = express();
  const PORT = 3000;
  
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  app.set("io", io);

  io.use((socket, next) => {
    const token = socket.handshake.auth.token;
    if (token) {
      jwt.verify(token, process.env.JWT_SECRET || 'supersecretkey', (err: any, decoded: any) => {
        if (err) return next();
        socket.data.user = decoded;
        next();
      });
    } else {
      next();
    }
  });

  io.on("connection", (socket) => {
    console.log("A user connected:", socket.id);
    
    if (socket.data.user) {
      // Join a room with their user ID so we can target them
      socket.join(socket.data.user.id);
      console.log(`User ${socket.data.user.id} joined their room`);
    }

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  app.use(express.json());

  // Connect to MongoDB
  await connectDB();
  await initWebPush();

  // API routes
  app.use("/api/auth", authRoutes);
  app.use("/api/requests", requestRoutes);
  app.use("/api/users", userRoutes);
  app.use("/api/direct-requests", directRequestRoutes);
  app.use("/api/notifications", notificationRoutes);

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
      configFile: path.resolve(process.cwd(), 'vite.config.ts'),
      root: path.resolve(process.cwd(), 'frontend'),
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
