import http from 'http';

http.get('http://localhost:3000/api/direct-requests?type=received', (res) => {
  console.log(`Status: ${res.statusCode}`);
  res.on('data', (d) => process.stdout.write(d));
}).on('error', (e) => {
  console.error(`Got error: ${e.message}`);
});
